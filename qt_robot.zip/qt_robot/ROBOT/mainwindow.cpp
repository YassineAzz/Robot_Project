#include "mainwindow.h"
#include "ui_mainwindow.h"


QString Uartport = "/dev/ttyACM0";
QString xbeeport = "/dev/ttyUSB0";

int Xspeed=0;



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{


 ui->setupUi(this);
    mes_to_send = new QLineEdit();
    mes_received = new QLineEdit();
  ui->horizontalSlider->setRange(0,3008);
  ui->horizontalSlider_3->setRange(0,3008);
  ui->dial->setRange(-180,180);
  ui->dial_2->setRange(-180,180);
   openUartPort();
   openXbeePort();

   timer_tick = new QTimer();
   connect( timer_tick, SIGNAL(timeout()), this, SLOT(onTimer_Tick()));


timer_tick -> start(1);// in ms

}

void MainWindow::onTimer_Tick()
{
    char *speed=" ";

     //   serial->read(speed,1);
     //   std::cout<<speed<<std::endl;
if(Xserial->isWritable())
{

ui->state_xbee->setText("You're free to send a msg");
ui->state_xbee->setStyleSheet("QLabel {color : green }");
}
else {
    ui->state_xbee->setText("\r\txbee is busy");
    ui->state_xbee->setStyleSheet("QLabel {color : red}");
}
}

void MainWindow::openUartPort()
{
    serial = new QSerialPort(this);
    serial->setPortName(Uartport);
    serial->open(QIODevice::ReadWrite);

     if( serial->isOpen()==false)
     {
          serial->clearError();
          QMessageBox::critical(this, "Port error", "Port: "+Uartport);
          QMessageBox::information(this, "Port error", "Vérifier nom du port \n Fermer tout programme utilisant la lisaison RS232 "+Uartport);
      }
   else
     {
         QMessageBox::information(this, "Port open", " "+Uartport);
          serial->setBaudRate(QSerialPort::Baud115200);
          serial->setStopBits(QSerialPort::OneStop);
          serial->setParity(QSerialPort::NoParity);
          serial->setDataBits(QSerialPort::Data8);
          serial->setFlowControl(QSerialPort::NoFlowControl);
     }
}

void MainWindow::openXbeePort()
{
    Xserial = new QSerialPort(this);
    Xserial->setPortName(xbeeport);
    Xserial->open(QIODevice::ReadWrite);

     if( Xserial->isOpen()==false)
     {
          Xserial->clearError();
          QMessageBox::critical(this, "Port error", "Port: "+xbeeport);
          QMessageBox::information(this, "Port error", "Vérifier nom du port \n Fermer tout programme utilisant la lisaison RS232 "+xbeeport);
      }
   else
     {
         QMessageBox::information(this, "Port open", " "+xbeeport);
          Xserial->setBaudRate(QSerialPort::Baud9600 );
          Xserial->setStopBits(QSerialPort::OneStop);
          Xserial->setParity(QSerialPort::NoParity);
          Xserial->setDataBits(QSerialPort::Data8);
          Xserial->setFlowControl(QSerialPort::NoFlowControl);
     }
}


MainWindow::~MainWindow()
{
    delete ui;
}
char message;

void MainWindow::on_horizontalSlider_valueChanged(int value)
{
     ui->lcdNumber->display(value);
char message= (char)value;
}

void MainWindow::on_horizontalSlider_3_valueChanged(int value)
{
    if(value>3000)
    {
        ui->zigbe_C->display((3000));
    }
    else {
         ui->zigbe_C->display((value>>5)<<5);
    }

      Xspeed=value>>5;
      double data=value;
      std::cout<<((data)/5)<<std::endl;
}

void MainWindow::on_dial_valueChanged(int value)
{
     ui->zigbee_D->display(value);
}

void MainWindow::on_dial_2_valueChanged(int value)
{
    ui->lcdNumber_6->display(value);
}

void MainWindow::XwriteData(char *msg,int data)
{  // Xserial->write(msg);
    Xserial->write(QString::number(data).toUtf8());
    std::cout<<data<<std::endl;
}


void MainWindow::on_horizontalSlider_sliderReleased()
{
    printf("%s",message);
     serial->write(&message);

}

void MainWindow::on_horizontalSlider_3_sliderReleased()
{
   MainWindow::XwriteData("S",Xspeed);



}


void MainWindow::on_pushButton_10_clicked()
{
      Xserial->write("ff");
}

void MainWindow::on_pushButton_7_clicked()
{
          Xserial->write("ss");
}

void MainWindow::on_pushButton_8_clicked()
{
          Xserial->write("rr");
}

void MainWindow::on_pushButton_9_clicked()
{
          Xserial->write("ll");
}

void MainWindow::on_pushButton_11_clicked()
{
          Xserial->write("bb");
}

void MainWindow::on_pushButton_2_clicked()
{
     serial->write("ff");
}

void MainWindow::on_pushButton_6_clicked()
{
    serial->write("ss");
}

void MainWindow::on_pushButton_4_clicked()
{
    serial->write("ll");
}

void MainWindow::on_pushButton_3_clicked()
{
    serial->write("rr");
}

void MainWindow::on_pushButton_5_clicked()
{
    serial->write("bb");
}


void MainWindow::on_lineEdit_textChanged(const QString &arg1)
{
   angle=arg1.QString::toInt();

i=1;
}

void MainWindow::on_lineEdit_editingFinished()
{
    if((angle<20 || angle >120) && i==1 )
    {
        Xserial->clearError();
        i=0;
        QMessageBox::critical(this, "Fatal Error", "plaisse give a number between 20 and 120");

    }
}



void MainWindow::on_pushButton_15_clicked(bool checked)
{   int x=(angle>>2)+95;
    std::cout<<x<<std::endl;
    //std::cout<<((x-'A')<<2)<<std::endl;
    MainWindow::XwriteData("H",x);


}

void MainWindow::on_pushButton_16_clicked(bool checked)
{
    int x=(angle>>2)+110;
     std::cout<<x<<std::endl;
     //std::cout<<((x-'X')<<2)<<std::endl;
     MainWindow::XwriteData("L",x);

}



void MainWindow::on_pushButton_12_clicked()
{
    serial->write("SS");
}

void MainWindow::on_pushButton_13_clicked()
{
    serial->write("UU");
}

void MainWindow::on_pushButton_14_clicked()
{
    serial->write("DD");
}

void MainWindow::on_pushButton_15_clicked()
{
    serial->write("LL");
}

void MainWindow::on_pushButton_16_clicked()
{
    serial->write("RR");
}

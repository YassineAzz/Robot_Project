#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QtSerialPort/QSerialPort>

#include <QString>
#include<iostream>
#include <QMessageBox>
#include <QLineEdit>
#include <QTimer>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
public slots :
    void openUartPort();
      void openXbeePort();
    void XwriteData(char *,int );
     void onTimer_Tick();

private slots:


    void on_horizontalSlider_valueChanged(int value);

    void on_horizontalSlider_3_valueChanged(int value);

    void on_dial_valueChanged(int value);

    void on_dial_2_valueChanged(int value);

    void on_horizontalSlider_sliderReleased();

    void on_horizontalSlider_3_sliderReleased();



    void on_pushButton_10_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_11_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_5_clicked();

    void on_lineEdit_textChanged(const QString &arg1);

    void on_lineEdit_editingFinished();



    void on_pushButton_15_clicked(bool checked);

    void on_pushButton_16_clicked(bool checked);



    void on_pushButton_12_clicked();

    void on_pushButton_13_clicked();

    void on_pushButton_14_clicked();

    void on_pushButton_15_clicked();

    void on_pushButton_16_clicked();

private:
    Ui::MainWindow *ui;
     QSerialPort *serial,*Xserial;
    QLineEdit   *mes_to_send;
    QLineEdit   *mes_received;
    QTimer *timer_tick;
    int angle=0,i=0;
};

#endif // MAINWINDOW_H

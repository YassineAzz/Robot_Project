/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDial>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QSlider *horizontalSlider;
    QLabel *label;
    QLCDNumber *lcdNumber;
    QLCDNumber *lcdNumber_2;
    QLabel *label_2;
    QLabel *label_3;
    QDial *dial_2;
    QLCDNumber *lcdNumber_6;
    QLabel *label_11;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QWidget *tab_2;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QSlider *horizontalSlider_3;
    QLCDNumber *zigbe_C;
    QLCDNumber *zigbee_R;
    QDial *dial;
    QLCDNumber *zigbee_D;
    QLabel *label_10;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QLabel *state_xbee;
    QLabel *label_4;
    QLabel *label_5;
    QFrame *line;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QPushButton *pushButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(714, 383);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(50, 0, 661, 321));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        horizontalSlider = new QSlider(tab);
        horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
        horizontalSlider->setGeometry(QRect(100, 40, 341, 16));
        horizontalSlider->setMaximum(0);
        horizontalSlider->setOrientation(Qt::Horizontal);
        label = new QLabel(tab);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 40, 51, 16));
        lcdNumber = new QLCDNumber(tab);
        lcdNumber->setObjectName(QStringLiteral("lcdNumber"));
        lcdNumber->setGeometry(QRect(470, 30, 64, 31));
        lcdNumber_2 = new QLCDNumber(tab);
        lcdNumber_2->setObjectName(QStringLiteral("lcdNumber_2"));
        lcdNumber_2->setGeometry(QRect(550, 30, 64, 31));
        label_2 = new QLabel(tab);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(470, 10, 61, 15));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(550, 10, 71, 16));
        dial_2 = new QDial(tab);
        dial_2->setObjectName(QStringLiteral("dial_2"));
        dial_2->setGeometry(QRect(470, 90, 50, 64));
        lcdNumber_6 = new QLCDNumber(tab);
        lcdNumber_6->setObjectName(QStringLiteral("lcdNumber_6"));
        lcdNumber_6->setGeometry(QRect(540, 110, 64, 31));
        label_11 = new QLabel(tab);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(540, 90, 61, 15));
        pushButton_2 = new QPushButton(tab);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(110, 100, 82, 23));
        pushButton_3 = new QPushButton(tab);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(210, 140, 82, 23));
        pushButton_4 = new QPushButton(tab);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(10, 140, 82, 23));
        pushButton_5 = new QPushButton(tab);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(110, 190, 82, 23));
        pushButton_6 = new QPushButton(tab);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(110, 140, 82, 23));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        label_7 = new QLabel(tab_2);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(460, 10, 61, 15));
        label_8 = new QLabel(tab_2);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(540, 10, 71, 16));
        label_9 = new QLabel(tab_2);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(40, 40, 51, 16));
        horizontalSlider_3 = new QSlider(tab_2);
        horizontalSlider_3->setObjectName(QStringLiteral("horizontalSlider_3"));
        horizontalSlider_3->setGeometry(QRect(100, 40, 331, 16));
        horizontalSlider_3->setMaximum(1500);
        horizontalSlider_3->setOrientation(Qt::Horizontal);
        zigbe_C = new QLCDNumber(tab_2);
        zigbe_C->setObjectName(QStringLiteral("zigbe_C"));
        zigbe_C->setGeometry(QRect(460, 30, 64, 31));
        zigbee_R = new QLCDNumber(tab_2);
        zigbee_R->setObjectName(QStringLiteral("zigbee_R"));
        zigbee_R->setGeometry(QRect(540, 30, 64, 31));
        dial = new QDial(tab_2);
        dial->setObjectName(QStringLiteral("dial"));
        dial->setGeometry(QRect(470, 90, 50, 64));
        zigbee_D = new QLCDNumber(tab_2);
        zigbee_D->setObjectName(QStringLiteral("zigbee_D"));
        zigbee_D->setGeometry(QRect(540, 110, 64, 31));
        label_10 = new QLabel(tab_2);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(540, 90, 51, 16));
        pushButton_7 = new QPushButton(tab_2);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(130, 210, 82, 23));
        pushButton_8 = new QPushButton(tab_2);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(230, 210, 82, 23));
        pushButton_9 = new QPushButton(tab_2);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(30, 210, 82, 23));
        pushButton_10 = new QPushButton(tab_2);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(130, 170, 82, 23));
        pushButton_11 = new QPushButton(tab_2);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(130, 260, 82, 23));
        state_xbee = new QLabel(tab_2);
        state_xbee->setObjectName(QStringLiteral("state_xbee"));
        state_xbee->setGeometry(QRect(80, 80, 331, 16));
        label_4 = new QLabel(tab_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(20, 150, 47, 13));
        label_5 = new QLabel(tab_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(430, 150, 47, 13));
        line = new QFrame(tab_2);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(340, 150, 16, 141));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        pushButton_12 = new QPushButton(tab_2);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(470, 210, 82, 23));
        pushButton_13 = new QPushButton(tab_2);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(470, 170, 82, 23));
        pushButton_14 = new QPushButton(tab_2);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(460, 260, 101, 23));
        pushButton_15 = new QPushButton(tab_2);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setGeometry(QRect(370, 210, 82, 23));
        pushButton_16 = new QPushButton(tab_2);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(570, 210, 82, 23));
        tabWidget->addTab(tab_2, QString());
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(0, 140, 51, 23));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 714, 20));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Consigne", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Real speed", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "Degr\303\251e", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "Forward", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("MainWindow", "Right", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("MainWindow", "Left", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("MainWindow", "Backward", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "UART", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "Consigne", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Real speed", Q_NULLPTR));
        label_9->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "Degr\303\251e", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("MainWindow", "Right", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("MainWindow", "Left", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("MainWindow", "Forward", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("MainWindow", "Backward", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        state_xbee->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><br/></p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        state_xbee->setText(QString());
        label_4->setText(QApplication::translate("MainWindow", "MOTOR :", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "SERVO :", Q_NULLPTR));
        pushButton_12->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        pushButton_13->setText(QApplication::translate("MainWindow", "HIGH_UP", Q_NULLPTR));
        pushButton_14->setText(QApplication::translate("MainWindow", "HIGH_DOWN", Q_NULLPTR));
        pushButton_15->setText(QApplication::translate("MainWindow", "LOW_LEFT", Q_NULLPTR));
        pushButton_16->setText(QApplication::translate("MainWindow", "LOW_RIGHT", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "zigbee", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "Quitter", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

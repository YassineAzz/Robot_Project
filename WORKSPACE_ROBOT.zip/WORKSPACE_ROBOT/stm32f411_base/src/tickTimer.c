/*

 * TickTimer.c
 *
 *  Created on: Feb 24, 2015
 *      Author: kerhoas
 */

#include "tickTimer.h"
double spee[500];
double posL[2]={0,0};
double posR[2]={0,0};
int j=0;

TIM_HandleTypeDef    TimHandle_period;

//================================================
//				TIMER 5 INIT
//================================================

void tickTimerInit(int periode)
{

	unsigned int uwPrescalerValue;

/* Compute the prescaler value to have TIM5 counter clock equal to 10 KHz */
  uwPrescalerValue = (unsigned int) ((SystemCoreClock / 10000) - 1);

  TimHandle_period.Instance = TIM5;
  TimHandle_period.Init.Period = periode - 1;
  TimHandle_period.Init.Prescaler = uwPrescalerValue;
  TimHandle_period.Init.ClockDivision = 0;
  TimHandle_period.Init.CounterMode = TIM_COUNTERMODE_UP;
  HAL_TIM_Base_Init(&TimHandle_period);

  HAL_TIM_Base_Start_IT(&TimHandle_period);
}


int i=0;
//================================================
//			TIMER 5 CALLBACK PERIOD
//================================================

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);	// TOGGLE LED
/*
// SemGive From Interrupt Callback :
// REM : Interrupt Priority (cf stm32f4xx_hal_msp.c) > #define configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY (cf FreeRTOSConfig.h)
static BaseType_t xHigherPriorityTaskWoken;
xSemaphoreGiveFromISR( xSemaphore,&xHigherPriorityTaskWoken );
portYIELD_FROM_ISR( xHigherPriorityTaskWoken );
*/

	speed[0]=quadEncoder_GetSpeedL();
	speed[1]=quadEncoder_GetSpeedR();

	posL[1]=speed[0];
	posR[1]=speed[1];

	poss[0]=quadEncoder_GetPos32L();
	posL[0]=posL[1];

	poss[1]=quadEncoder_GetPos32R();
	posR[0]=posR[1];
//	term_printf("posL => %f , posR => %f",poss[0],poss[1]);


	/*	spee[i]=quadEncoder_GetSpeedL();
	 *
	i++;*/
if(i==1000)
{int x=(speed[0]+speed[1])/2;
	i=0;
	if(speed[0]==0 || speed[1]==0)
	{
		putchar(x*2);
	}
	else{
	term_printf_zigbee(x);}
}
i++;
}
//================================================


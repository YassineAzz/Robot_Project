/*
 * MotorCommand.c
 */

#include "motorCommand.h"

double Kp=0.1;
double Ki=0.5;//0.05/8.5;
double Kp_g=0.00001;
double Ki_g=1.75;
double Up_g=0;
double Un_g[2]={0,0};
double C_g=0;

double Un[2]={0,0};
double Up=0;
double err=0;
double C=0;
double duty=0;

double Un_r[2]={0,0};
double Up_r=0;
double err_r=0;
double C_r=0;
double duty_r=0;

double err_gliss;

double UN[2];
double KP=4;
double KI=1;
double Err=0;
double Cc ,UP ;
double dutyD , dutyG;
//extern int poss[2];


static TIM_HandleTypeDef    TimHandle;
static TIM_OC_InitTypeDef   sConfigOC;

//=================================================================
//			PWM INIT
// TIMER 4 (PWM)  : CH1 et CH2
// ENABLE : Sortie Logique (GPIO) PA15
//=================================================================

void motorCommand_Init(void)
{
	unsigned int uwPrescalerValue = 0;

	/* Compute the prescaler value to have TIM4 counter clock equal to 10MHz */
	  uwPrescalerValue = (unsigned int) ((SystemCoreClock / 10000000) - 1);
	  TimHandle.Instance = TIM4;
	  TimHandle.Init.Period = 200 - 1; // 100MHz/200=50kHz
	  TimHandle.Init.Prescaler = uwPrescalerValue;
	  TimHandle.Init.ClockDivision = 0;
	  TimHandle.Init.CounterMode = TIM_COUNTERMODE_UP;

	  HAL_TIM_Base_Init(&TimHandle);

	  sConfigOC.OCMode = TIM_OCMODE_PWM1;
	  sConfigOC.Pulse = 0x5;// Specifies the pulse value to be loaded into the Capture Compare Register. This parameter can be a number between Min_Data = 0x0000 and Max_Data = 0xFFFF */

	  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;

	 HAL_TIM_PWM_ConfigChannel(&TimHandle, &sConfigOC, TIM_CHANNEL_1);
	 HAL_TIM_PWM_ConfigChannel(&TimHandle, &sConfigOC, TIM_CHANNEL_2);

	 // CHANGEMENT DU RAPPORT CYCLIQUE
	 __HAL_TIM_SetCompare(&TimHandle, TIM_CHANNEL_1, 100);	// 100 : moteurs au repos
	 __HAL_TIM_SetCompare(&TimHandle, TIM_CHANNEL_2, 100);

	  HAL_TIM_PWM_Start(&TimHandle, TIM_CHANNEL_1);	// MOTOR RIGHT
	  HAL_TIM_PWM_Start(&TimHandle, TIM_CHANNEL_2); // MOTOR LEFT

	  // ENABLE MOTEUR (SI INVERSEUR)
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, 0);
}

//=================================================================
//			SET DUTY CYCLE LEFT
//=================================================================
void motorLeft_SetDuty(int duty)
{
	__HAL_TIM_SetCompare(&TimHandle, TIM_CHANNEL_1, duty);
}
//=================================================================
//			SET DUTY CYCLE RIGHT
//=================================================================
void motorRight_SetDuty(int duty)
{
	__HAL_TIM_SetCompare(&TimHandle, TIM_CHANNEL_2, duty);
}
//=================================================================
void aserv_Motor(int channel ,int t_speed,double err_g)
{




if(channel==LEFT){
	/*if(t_speed==0){motorLeft_SetDuty(100);}
	else{*/
	err=t_speed-speed[0];

	Up=Kp*err ;

	Un[1]=Un[0]+(Kp*Ki)*err;
	Un[0]=Un[1];
	C=Up+Un[0];

	duty=C;

	duty=100+duty;


	if(duty<0){
		duty=0;
		motorLeft_SetDuty(0);
		}
	else if (duty>200) {

		duty=200;
		motorLeft_SetDuty(200);

	}

	else {motorLeft_SetDuty((int )duty);}
	//term_printf("LEFT => duty = %f ,speed = %f ,erreur = %f ,erreur_gilsement = %f \r\n",duty,t_speed,err,err_g);
}//}

if(channel==BOTH){
	/*if(t_speed==0){motorLeft_SetDuty(100);motorRight_SetDuty(100);}
	else{*/
err_gliss=0-(speed[0]-speed[1]);
Up_g=err_gliss*Kp_g;
//Un_g[1]=Un_g[0]+(Kp_g*Ki_g)*err_g;
//Un_g[0]=Un_g[1];
C_g=Up_g+Un_g[0];


err_r=t_speed-speed[1]-C_g;
err=t_speed-speed[0]+C_g;


	Up=Kp*err ;
	Up_r=Kp*err_r ;

	Un[1]=Un[0]+(Kp*Ki)*err;
	Un_r[1]=Un_r[0]+(Kp*Ki)*err_r;
	Un[0]=Un[1];
	Un_r[0]=Un_r[1];
	C=Up+Un[0];
	C_r=Up_r+Un_r[0];


	duty_r=C_r;
	duty=C;

	duty_r=100+duty_r;
	duty=100+duty;

	if(duty<0){
		duty=0;
		motorLeft_SetDuty(0);
	}
	else if (duty>200) {

		duty=200;
		motorLeft_SetDuty(200);

	}


	if(duty_r<0){
		duty_r=0;
		motorRight_SetDuty(0);
	}
	else if (duty_r>200) {

		duty_r=200;
		motorRight_SetDuty(200);

	}

	else {motorRight_SetDuty((int )duty_r);motorLeft_SetDuty((int )duty);}
	//term_printf("LEFT => duty = %f ,speed = %f ,erreur = %f ,erreur_gilsement = %f \r\n",duty,t_speed,err,err_g);
	//term_printf("RIGHT => duty = %f ,speed = %f ,erreur = %f ,erreur_gilsement = %f \r\n",duty_r,t_speed,err_r,err_g);



}//}

if(channel==RIGHT){
	/*if(t_speed==0){motorRight_SetDuty(100);}
	else {*/err_r=t_speed-speed[1];

	Up=Kp*err_r ;

	Un_r[1]=Un_r[0]+(Kp*Ki)*err_r;
	Un_r[0]=Un_r[1];
	C_r=Up_r+Un_r[0];

	duty_r=C_r;

	duty_r=100+duty_r;


	if(duty_r<0){
		duty_r=0;
		motorRight_SetDuty(0);
	}
	else if (duty_r>200) {

		duty_r=200;
		motorRight_SetDuty(200);

	}

	else {motorRight_SetDuty((int )duty_r);}
	//term_printf("RIGHT => duty = %f ,speed = %f ,erreur = %f ,erreur_gilsement = %f \r\n",duty_r,t_speed,err_r,err_g);
}//}
}

void aserv_pos(int channel,int pos)

{
/*
	Err=pos-(poss[1]-poss[0]);





	UP=KP*Err ;

	UN[1]=UN[0]+(KP*KI)*Err;
	Un[0]=Un[1];
	Cc=UP+UN[0];

	dutyD=Cc;
	dutyG=-Cc;



	dutyD=100+dutyD;
	dutyG=100+dutyG;

	if(dutyG<0){
			dutyG=0;
			motorLeft_SetDuty(0);
		}
		else if (dutyG>200) {

			dutyG=200;
			motorLeft_SetDuty(200);

		}


		if(dutyD<0){
			dutyD=0;
			motorRight_SetDuty(0);
		}
		else if (dutyD>200) {

			dutyD=200;
			motorRight_SetDuty(200);

		}

		else {motorRight_SetDuty((int )dutyD);motorLeft_SetDuty((int )dutyG);}
		term_printf("LEFT => duty = %f ,speed = %f   \r\n",duty,pos);
			term_printf("RIGHT => duty = %f ,speed = %f \r\n",duty_r,pos);*/
	if(channel==LEFT)
		{

		double new_pos=map(pos,0,360,0,2500);
		term_printf("pos => %f",new_pos);
		aserv_Motor(LEFT,0,0);
		aserv_Motor(RIGHT,-500,0);
		if(new_pos>=poss[0] || new_pos>=poss[1])
		{
			aserv_Motor(BOTH,0,0);
		}
		}
	if(channel==RIGHT)
		{

		double new_pos=map(pos,0,360,0,2500);
		term_printf("pos => %f",new_pos);
		aserv_Motor(LEFT,-500,0);
		aserv_Motor(RIGHT,0,0);
		if(new_pos>=poss[0] || new_pos>=poss[1])
		{
			aserv_Motor(BOTH,0,0);
		}
		}




}





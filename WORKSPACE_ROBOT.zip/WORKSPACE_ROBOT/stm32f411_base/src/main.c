#include "main.h"
#include <Pixy.h>

// Déclaration des objets synchronisants !! Ne pas oublier de les créer
xSemaphoreHandle xLCD = NULL,xman = NULL,xnav=NULL,xpixycam=NULL,xpixymotor=NULL,xUS=NULL,xstarter=NULL,xdemo=NULL,xstop=NULL;
xQueueHandle qh = NULL,stop=NULL;
int dem=1;
struct AMessage
{
	char command;
	int data;
};


int X=0;
servol panLoop;
servol tiltLoop;

extern consigne T;
servol ServoLoop(int32_t pgain, int32_t dgain)
{
	servol p;
  p.m_pos = PIXY_RCS_CENTER_POS;
  p.m_pgain = pgain;
  p.m_dgain = dgain;
  p.m_prevError = 0x80000000L;
  return p;
}

void update(servol *p,int32_t error)
{
  long int vel;
  char buf[32];
  if (p->m_prevError!=0x80000000)
  	{
    vel = (error*p->m_pgain + (error - p->m_prevError)*p->m_dgain)>>10;
    p->m_pos += vel;
    if (p->m_pos>PIXY_RCS_MAX_POS)
    	p->m_pos = PIXY_RCS_MAX_POS;
    else if (p->m_pos<PIXY_RCS_MIN_POS)
    	p->m_pos = PIXY_RCS_MIN_POS;
    if(p->m_pos<20)
    {
    	p->m_pos=20;

    }
    else if (p->m_pos >120)
    {
    	p->m_pos=120;
    }
  	}
  		p->m_prevError = error;
}




//========================================================
static void task_nav(void *pvParameters)

{
	while(1){
		xSemaphoreTake(xnav,portMAX_DELAY);

		int IR[2];

		captDistIR_Get(IR);
		//double x= log10( (double) IR[0]);
		term_printf(" IR G => %d , IR D => %d \r\n",IR[0],IR[1]);
		term_printf(" US G => %d , US D => %d \r\n",ultrason_ditance[0],ultrason_ditance[1]);

		if(IR_DISTANCE_LIMITE<IR[0] )
			{
			//T.modif=0;

			aserv_Motor(BOTH,0,0);//HAL_Delay(200);

			aserv_Motor(BOTH,-500,0);//HAL_Delay(200);
			aserv_pos(LEFT,90);

			//T.modif=1;
			}
		else if(  IR_DISTANCE_LIMITE <IR[1])
			{
			//T.modif=0;

			aserv_Motor(BOTH,0,0);//HAL_Delay(200);
			aserv_Motor(BOTH,-500,0);//HAL_Delay(200);
			aserv_pos(RIGHT,90);

			//T.modif=1;
			}

		else if(( ultrason_ditance[0]>0 && ultrason_ditance[0]<US_DISTANCE_LIMITE) && (ultrason_ditance[1]>0  && ultrason_ditance[1] < US_DISTANCE_LIMITE)){
				//T.modif=0;
				aserv_Motor(BOTH,0,0);
				aserv_Motor(BOTH,0,0);
				aserv_Motor(BOTH,0,0);

				aserv_Motor(BOTH,500,0);
				aserv_Motor(BOTH,500,0);
				aserv_Motor(BOTH,500,0);

				//T.modif=1;
				}

		else if(( ultrason_ditance[0]>0 && ultrason_ditance[0]<US_DISTANCE_LIMITE) ){//T.modif=0;
	aserv_Motor(BOTH,0,0);
	//T.modif=1;
	}
		else if( (ultrason_ditance[1]>0  && ultrason_ditance[1] < US_DISTANCE_LIMITE))
				{//T.modif=0;
			aserv_Motor(BOTH,0,0);
			//T.modif=1;

			}







		else {
				aserv_Motor(BOTH,500,0);}
				//xSemaphoreGive(xmotor);



		xSemaphoreGive(xLCD);

		}

	}

static void task_man(void *pvParameters)
{


while(1){
	xSemaphoreTake(xman,portMAX_DELAY);
	int IR[2];

	if(T.pos_servo_H==1)
	{
		servoHigh_Set(servoHigh_Get()+1);
	}
	if(T.pos_servo_H==-1)
		{
			servoHigh_Set(servoHigh_Get()-1);
		}
	if(T.pos_servo_L==1)
	{
		servoLow_Set(servoLow_Get()+1);
	}
	if(T.pos_servo_L==-1)
		{
			servoLow_Set(servoLow_Get()-1);
		}

	captDistIR_Get(IR);
	//double x= log10( (double) IR[0]);
	//term_printf(" IR G => %d , IR D => %d \r\n",IR[0],IR[1]);
	//term_printf(" US G => %d , US D => %d \r\n",ultrason_ditance[0],ultrason_ditance[1]);

	if(IR_DISTANCE_LIMITE<IR[0] )
		{
		//T.modif=0;

		aserv_Motor(BOTH,0,0);//HAL_Delay(200);
		aserv_Motor(BOTH,-500,0);//HAL_Delay(200);
		aserv_pos(LEFT,90);

		//T.modif=1;
		}
	else if(  IR_DISTANCE_LIMITE <IR[1])
		{
		//T.modif=0;

		aserv_Motor(BOTH,0,0);//HAL_Delay(200);
		aserv_Motor(BOTH,-500,0);//HAL_Delay(200);
		aserv_pos(RIGHT,90);

		//T.modif=1;
		}

	else if(( ultrason_ditance[0]>0 && ultrason_ditance[0]<US_DISTANCE_LIMITE) && (ultrason_ditance[1]>0  && ultrason_ditance[1] < US_DISTANCE_LIMITE)){
			//T.modif=0;
			aserv_Motor(BOTH,0,0);
			aserv_Motor(BOTH,0,0);
			aserv_Motor(BOTH,0,0);

			aserv_Motor(BOTH,500,0);
			aserv_Motor(BOTH,500,0);
			aserv_Motor(BOTH,500,0);

			//T.modif=1;
			}

	else if(( ultrason_ditance[0]>0 && ultrason_ditance[0]<US_DISTANCE_LIMITE) ){//T.modif=0;
aserv_Motor(BOTH,0,0);
//T.modif=1;
}
	/*else if( (ultrason_ditance[1]>0  && ultrason_ditance[1] < US_DISTANCE_LIMITE))
			{//T.modif=0;
		aserv_Motor(BOTH,0,0);
		//T.modif=1;

		}*/







	else {T.modif=1;
			aserv_Motor(T.channel,T.vitesse,0);}






	}

xSemaphoreGive(xLCD);

	}


static void task_LCD(void *pvParameters)
{
	while(dem)
	{
		xSemaphoreTake(xLCD , portMAX_DELAY );

		screenLCD_Clear();
		char *state= robot_state();
		screenLCD_Write("state :",7,0,1);
		screenLCD_Write(state,8,8,1);
		screenLCD_Write("Rspeed :",6,0,2);
		char speed[10];
		num2str(speed,speed[0],10,3,0);
		screenLCD_Write(speed,3,7,2);
		HAL_Delay(100);
		captDistUS_Measure(ADDRL);
		captDistUS_Measure(ADDRR);
		HAL_Delay(100);
		ultrason_ditance[0]=captDistUS_Get(ADDRL);
		ultrason_ditance[1]=captDistUS_Get(ADDRR);
		xSemaphoreGive(xUS);
	}
}
//========================================================

static void task_pixym( void *pvParameters )
{
	while(1)
	{xSemaphoreTake(xpixymotor , portMAX_DELAY );

		pixyCam_Get(XY,WH,&Angle);

	if(WH[0]<150){
		if(XY[0]<164)
		{
			motorLeft_SetDuty(100);
			motorRight_SetDuty(130);

		}

		else if(XY[0]>164)
		{
			motorRight_SetDuty(100);
			motorLeft_SetDuty(130);

		}
		else
		{
			motorLeft_SetDuty(150);
			motorRight_SetDuty(150);

		}
		}
	else if(WH[0]>200)
	{
		motorLeft_SetDuty(50);
		motorRight_SetDuty(50);
	}
	else
	{
		motorLeft_SetDuty(100);
		motorRight_SetDuty(100);
	}
	HAL_Delay(100);
	xSemaphoreGive(xstarter);

	}
}

static void task_pixyc( void *pvParameters )
{
	while(1)
	{
		xSemaphoreTake(xpixycam,portMAX_DELAY);
		static int i = 0;
		  int j;

		  int32_t panError, tiltError;

		  pixyCam_Get(XY,WH,&Angle);

			term_printf_stlink("x = %d \n\r",XY[0]);
				term_printf_stlink("y = %d \n\r",XY[1]);
				term_printf_stlink("width = %d \n\r",WH[0]);
				term_printf_stlink("height = %d \n\r",WH[1]);

		    panError = X_CENTER-XY[0];
		    tiltError = XY[1]-Y_CENTER;
		    if(WH[0]>75){
		    update(&panLoop,panError);
		    update(&tiltLoop,tiltError);
		   }

		    servoLow_Set(panLoop.m_pos);
		    servoHigh_Set(tiltLoop.m_pos);

		    term_printf("angle2 = %d \n\r",panLoop.m_pos);
		    HAL_Delay(100);
		    xSemaphoreGive(xstarter);


	}
}

//========================================================

static void task_demo( void *pvParameters )
{
	struct AMessage pxRxedMessage;


	for (;;)
	{
		term_printf("task demo\r\n");
		xSemaphoreTake(xdemo,portMAX_DELAY);
//-----------------------------------------------------
		for(int i =20;i<120;i++)
				{
					servoLow_Set(i);
					HAL_Delay(5);
				}
		for(int i =120;i>20;i--)
				{
					servoLow_Set(i);
					HAL_Delay(5);
				}

//-----------------------------------------------------
		for(int i =20;i<120;i++)
				{
					servoHigh_Set(i);
					HAL_Delay(5);
				}
		for(int i =120;i>20;i--)
					{
						servoHigh_Set(i);
						HAL_Delay(5);
					}
		servoLow_Set(80);HAL_Delay(5);
		servoHigh_Set(70);HAL_Delay(5);
		aserv_Motor(BOTH,500,0);HAL_Delay(500);
		aserv_Motor(LEFT,500,0);
		aserv_Motor(RIGHT,0,0);;HAL_Delay(500);
		aserv_Motor(LEFT,0,0);
		aserv_Motor(RIGHT,500,0);HAL_Delay(500);
		aserv_Motor(LEFT,500,0);
		aserv_Motor(RIGHT,-500,0);HAL_Delay(500);
		aserv_Motor(BOTH,0,0);HAL_Delay(500);
		motorLeft_SetDuty(100);
		motorRight_SetDuty(100);
		xSemaphoreGive(xstarter);



	}
}

static void task_stop( void *pvParameters )
{
	struct AMessage pxRxedMessage;


	for (;;)
	{
		term_printf("task stop\r\n");
		xSemaphoreTake(xstop,portMAX_DELAY);
		motorLeft_SetDuty(100);
		motorRight_SetDuty(100);
		servoHigh_Set(70);
		servoLow_Set(70);
		xSemaphoreGive(xstarter);

	}
}
static void task_us(void *pvParameters)
{
	for(;;)
	{
		xSemaphoreTake(xUS,portMAX_DELAY);
		captDistUS_Measure(ADDRL);
		HAL_Delay(70);
		ultrason_ditance[0]=captDistUS_Get(ADDRL);
		HAL_Delay(10);
		captDistUS_Measure(ADDRR);
		HAL_Delay(70);
		ultrason_ditance[1]=captDistUS_Get(ADDRR);
	xSemaphoreGive(xstarter);
	}
}

static void task_start(void *pvParameters)
{
        int test=1;
        int test1=1;
        int mode=15,mode1 =15;
        screenLCD_Clear();
        screenLCD_Write("demo",sizeof("demo")-1,0,0);
        screenLCD_Write("start",sizeof("stop")-1,sizeof("demo"),0);
        screenLCD_Write("stop",sizeof("stop")-1,sizeof("demo")+sizeof("start"),0);
        for (;;)
        {
                xSemaphoreTake(xstarter,portMAX_DELAY);

                term_printf("TASK A %d\n\r",screenLCD_ReadButtons());
                if(screenLCD_ReadButtons()!=15){
                    mode=screenLCD_ReadButtons();
                    mode1=0;
                }else if(mode==13){
                    mode=15;
                    mode1=0;
                }else if(mode==11){
                    switch(mode1){
                                                case 14:
                                                    xSemaphoreGive(xnav);
                                                    break;
                                                case 7:
                                                    xSemaphoreGive(xpixymotor);
                                                    break;
                                                case 11:
                                                    xSemaphoreGive(xpixycam);
                                                    break;
                                                case 13:
                                                    xSemaphoreGive(xman);
                                                    break;
                                                default:
                                                    xSemaphoreGive(xstarter);
                                                    break;
                                        }
                    continue;
                }

                switch(mode)
                {
                case 11 :
                        screenLCD_Clear();
                        screenLCD_Write("nav",sizeof("nav")-1,0,0);
                        screenLCD_Write("man",sizeof("man")-1,sizeof("nav"),0);
                        screenLCD_Write("Pic",sizeof("Pic")-1,sizeof("nav")+sizeof("man"),0);
                        screenLCD_Write("PiM",sizeof("PiM")-1,sizeof("nav")+sizeof("man")+sizeof("Pic"),0);
                    while(screenLCD_ReadButtons()==11){term_printf("relacher button\n\r");}
                    while((mode1=screenLCD_ReadButtons())==15){term_printf("sous menu\n\r");}
                    while(screenLCD_ReadButtons()!=15){term_printf("relacher button\n\r");
                    screenLCD_Write("relacher button",sizeof("relacher button")-1,0,1);
                    }
                    switch(mode1){
                            case 14:
                                xSemaphoreGive(xnav);
                                break;
                            case 7:
                                xSemaphoreGive(xman);
                                break;
                            case 11:
                                xSemaphoreGive(xpixycam);
                                break;
                            case 13:
                            	term_printf("test\r\n");
                                xSemaphoreGive(xpixymotor);
                                break;
                            default:
                                xSemaphoreGive(xstarter);
                                break;
                    }
                    screenLCD_Clear();
                    screenLCD_Write("demo",sizeof("demo")-1,0,0);
                    screenLCD_Write("start",sizeof("stop")-1,sizeof("demo"),0);
                    screenLCD_Write("stop",sizeof("stop")-1,sizeof("demo")+sizeof("start"),0);
                    break;
                case 7:
                    xSemaphoreGive(xstop);
                    break;
                case 13:
                    xSemaphoreGive(xdemo);

                    break;
                default:
                    xSemaphoreGive(xstarter);
                    break;
                }



        }
}
//=========================================================
//						map
//==========================================================

long map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
//=========================================================
//	>>>>>>>>>>>>	MAIN	<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//=========================================================

int main(void)
{
	HAL_Init();
	SystemClock_Config();
	uart2_Init();			// CABLE
	uart6_Init();			// ZIGBEE
	i2c1_Init();
	spi1Init();
	pixyCam_Init();			// Caméra Pixy
	captDistIR_Init();		// Capteurs Infrarouge
	quadEncoder_Init();		// Encodeurs Incrémentaux
	motorCommand_Init();	// Commande des Hacheurs
	servoCommand_Init();	// Commande des Servomoteurs

	HAL_Delay(1000);

motorLeft_SetDuty(50);
motorRight_SetDuty(50);
	screenLCD_SetBacklight(200);
	panLoop = ServoLoop(30, 50);
	tiltLoop = ServoLoop (50, 70);


	vSemaphoreCreateBinary(xLCD);//
	vSemaphoreCreateBinary(xnav);//
	vSemaphoreCreateBinary(xpixycam);//
	vSemaphoreCreateBinary(xstop);//
	vSemaphoreCreateBinary(xstarter);//
	vSemaphoreCreateBinary(xman);//
	vSemaphoreCreateBinary(xpixymotor);//
	vSemaphoreCreateBinary(xdemo);//
	vSemaphoreCreateBinary(xUS);//

	xSemaphoreTake(xLCD,portMAX_DELAY);
	xSemaphoreTake(xpixycam,portMAX_DELAY);
	xSemaphoreTake(xstop,portMAX_DELAY);
	xSemaphoreTake(xdemo,portMAX_DELAY);
	xSemaphoreTake(xnav,portMAX_DELAY);
	xSemaphoreTake(xpixymotor,portMAX_DELAY);
	xSemaphoreTake(xman,portMAX_DELAY);
	xSemaphoreTake(xUS,portMAX_DELAY);




	xTaskCreate( task_nav, ( const portCHAR * ) "taskVit", 512 /* stack size */, NULL, tskIDLE_PRIORITY+1, NULL );
	xTaskCreate( task_us, ( const portCHAR * ) "taskVit", 512 /* stack size */, NULL, tskIDLE_PRIORITY+1, NULL );
	xTaskCreate( task_man, ( const portCHAR * ) "taskObs", 512 /* stack size */, NULL, tskIDLE_PRIORITY+1, NULL );
	xTaskCreate( task_LCD, ( const portCHAR * ) "task B", 512 /* stack size */, NULL, tskIDLE_PRIORITY+1, NULL );
	xTaskCreate( task_pixyc, ( signed portCHAR * ) "task C", 512 /* stack size */, NULL, tskIDLE_PRIORITY+1, NULL );
	xTaskCreate( task_pixym, ( signed portCHAR * ) "task D", 512 /* stack size */, NULL, tskIDLE_PRIORITY+1, NULL );
	xTaskCreate( task_demo, ( signed portCHAR * ) "task demo ", 512 /* stack size */, NULL, tskIDLE_PRIORITY+1, NULL );
	xTaskCreate( task_stop, ( signed portCHAR * ) "task stop", 512 /* stack size */, NULL, tskIDLE_PRIORITY+1, NULL );
 	xTaskCreate( task_start, ( signed portCHAR * ) "task start", 512 /* stack size */, NULL, tskIDLE_PRIORITY+4, NULL );



	pixyCam_GetStart();

	qh = xQueueCreate( 1, sizeof(struct AMessage ) );
	stop = xQueueCreate( 1, sizeof(struct AMessage ) );
	tickTimerInit(50);
	vTaskStartScheduler();

	return 0;

}

//=================================================================
// Called if stack overflow during execution
extern void vApplicationStackOverflowHook(xTaskHandle *pxTask,
		signed char *pcTaskName)
{
	//term_printf("stack overflow %x %s\r\n", pxTask, (portCHAR *)pcTaskName);
	/* If the parameters have been corrupted then inspect pxCurrentTCB to
	 * identify which task has overflowed its stack.
	 */
	for (;;) {
	}
}
//=================================================================
//This function is called by FreeRTOS idle task
extern void vApplicationIdleHook(void)
{
	xSemaphoreGive(xstarter);
}
//=================================================================
// brief This function is called by FreeRTOS each tick
extern void vApplicationTickHook(void)
{
//	HAL_IncTick();
}



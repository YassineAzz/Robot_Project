#include <Pixy.h>




/*servol ServoLoop(int32_t pgain, int32_t dgain)
{
	servol p;
  p.m_pos = PIXY_RCS_CENTER_POS;
  p.m_pgain = pgain;
  p.m_dgain = dgain;
  p.m_prevError = 0x80000000L;
  return p;
}

void update(servol *p,int32_t error)
{
  long int vel;
  char buf[32];
  if (p->m_prevError!=0x80000000)
  {
    vel = (error*p->m_pgain + (error - p->m_prevError)*p->m_dgain)>>10;
    //sprintf(buf, "%ld\n", vel);
    //Serial.print(buf);
    p->m_pos += vel;
    if (p->m_pos>PIXY_RCS_MAX_POS)
    	p->m_pos = PIXY_RCS_MAX_POS;
    else if (p->m_pos<PIXY_RCS_MIN_POS)
    	p->m_pos = PIXY_RCS_MIN_POS;
  }
  p->m_prevError = error;
}*/

/*
 * MotorCommand.h
 */

#ifndef INC_MOTORCOMMAND_H_
#define INC_MOTORCOMMAND_H_

#include "main.h"
#define LEFT 1
#define RIGHT 2
#define BOTH 3


void motorCommand_Init(void);
void motorLeft_SetDuty(int);
void motorRight_SetDuty(int);
void aserv_Motor(int  ,int ,double );
void aserv_pos(int ,int );

#endif /* INC_MOTORCOMMAND_H_ */


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#define IR_DISTANCE_LIMITE 1500
#define US_DISTANCE_LIMITE 50


/* Includes ------------------------------------------------------------------*/

#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

#include "stm32f4xx_nucleo.h"
#include "stm32f401xe.h"
#include "stm32f4xx_hal.h"
#include "captDistIR.h"
#include "captDistUltrason.h"
#include "config.h"
#include <math.h>
#include <errno.h>
#include "drv_uart.h"
#include "drv_i2c.h"
#include "drv_spi.h"

#include "SystemClock.h"
#include "motorCommand.h"
#include "servoCommand.h"
#include "quadEncoder.h"
#include "tickTimer.h"
#include "screenLCD.h"

#include "FreeRTOS.h"
#include "pixyCam.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "math.h"
#include "Pixy.h"


#include "util.h"

uint16_t XY[2];
uint16_t WH[2];
uint16_t Angle;

long map(long x, long in_min, long in_max, long out_min, long out_max);
extern servol ServoLoop(int32_t pgain, int32_t dgain);




#endif /* __MAIN_H */



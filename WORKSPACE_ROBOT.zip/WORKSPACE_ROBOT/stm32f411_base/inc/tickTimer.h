/*
 * TickTimer.h
 */
#include <stdint.h>

#ifndef INC_TICKTIMER_H_
#define INC_TICKTIMER_H_
#define ADDRL 0xE0
#define ADDRR 0xE2
uint16_t ultrason_ditance[2];

int speed[2];
int poss[2];

#include "main.h"



void tickTimerInit(int );
void tickTimerInit2(int );




#endif /* INC_TICKTIMER_H_ */

/*
 * utils.h
 */

#ifndef INC_UTIL_H_
#define INC_UTIL_H_

#include "main.h"

int int_to_str(int, char*, unsigned int);
void flush_ch(char*,int);
int size_ch(char*,int);


#endif /* INC_UTIL_H_ */

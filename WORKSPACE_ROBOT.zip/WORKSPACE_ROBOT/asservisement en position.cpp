#include <FlexiTimer2.h>

int increment=0;
int erreur=0;

const int maxPwm=24;

const float kp=8;
const float ki=2;
int somerreur=0;

int pwm=0;


void codeur(){
if(pwm>=0) {increment++;}
else{increment--;}
}

void asserv(int consigne){
erreur=consigne-increment;

int corr_p=erreur*kp;
if(corr_p>maxPwm){corr_p=maxPwm;}
if(corr_p<-maxPwm){corr_p=-maxPwm;}

if(abs(somerreur+erreur)*ki<maxPwm) { somerreur+=erreur;}
else {
somerreur=maxPwm/ki;
if(erreur<0) {somerreur*=-1;}

}
if(erreur==0) {somerreur=0;}

int corr_i=somerreur*ki;
if(corr_i>maxPwm){corr_i=maxPwm;}
if(corr_i<-maxPwm){corr_i=-maxPwm;}

pwm=corr_i+corr_p;
if(pwm>maxPwm){pwm=maxPwm;}
if(pwm<-maxPwm){pwm=-maxPwm;}

if(pwm>=0){analogWrite(6,pwm); analogWrite(5,0);}
else{analogWrite(5,-pwm); analogWrite(6,0);}


}
